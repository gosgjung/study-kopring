package io.history.kopring_plain

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class KopringPlainApplication

fun main(args: Array<String>) {
	runApplication<KopringPlainApplication>(*args)
}
