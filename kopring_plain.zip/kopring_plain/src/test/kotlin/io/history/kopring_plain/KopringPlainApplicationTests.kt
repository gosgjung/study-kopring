package io.history.kopring_plain

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class KopringPlainApplicationTests {

	@Test
	fun contextLoads() {
	}

}
