rootProject.name = "kopring_plain"
