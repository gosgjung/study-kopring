package io.testprj.kopring_webflux

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class KopringWebfluxApplicationTests {

	@Test
	fun contextLoads() {
	}

}
